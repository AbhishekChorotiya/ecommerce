import React from 'react'

const News = () => {
    return (
        <div class="alert alert-info d-flex justify-content-center mb-0" role="alert">
            Check Out The Amazing Offers and Sale Upto 50% Off!!
        </div>
    )
}

export default News